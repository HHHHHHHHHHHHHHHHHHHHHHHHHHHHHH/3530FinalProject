#Make sure result file is empty at first.
rm -rf temp.txt
touch temp.txt

#1. Hostname
echo "1. Node Name: "$(hostname) >> temp.txt

#2. Distribution/OS 
echo "2. Distribution: "$( cat /etc/*-release | grep "^ID=" | cut -d "=" -f2) >> temp.txt

#3. Check if it is 64
if [ $(getconf LONG_BIT) -eq 64 ]

then
	echo "3. Architecture: 64 bits" >> temp.txt
else
	echo "3. Architecture: 32 bits" >> temp.txt
fi

#4. Network adapter name
echo "4. Network adapter name: "$(ls /sys/class/net) >> temp.txt

#5. IP Address
echo "5. IP Address: "$(sudo ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1') >> temp.txt

#6. Users logged into the system
echo "6. Users logged into the system: "$(whoami) >> temp.txt

#7. HDD total space
echo "7. HDD total space: "$(df -h --total | tail -n 1 | tr -s " " | cut -d " " -f2) >> temp.txt

#8. HDD used space
echo "8. HDD used space: "$(df -h --total | tail -n 1 | tr -s " " | cut -d " " -f3) >> temp.txt

#9. Total memory
echo "9. Total memory: "$(free -h | sed -n 2p | tr -s " " | cut -d " " -f2) >> temp.txt

#10. Used memory
echo "10. Used memory: "$(free -h | sed -n 2p | tr -s " " | cut -d " " -f3) >> temp.txt

#11. Number of user accounts created after installation
echo "11. Number of user accounts created after installation: "$(awk -F: '($3>=1000)&&($1!="nobody"){print $1}' /etc/passwd | wc -l) >> temp.txt

#12. Number of users that were able to logging into the system from installation time
echo "12. Number of users that were able to logging into the system from installation time: "$(last | awk '($1!="wtmp"){print $1}' | sort -u | sed '/^\s*$/d' | wc -l) >> temp.txt

#13. The date of first-time login
echo "13. First login time: "$(last w | sed '/^\s*$/d' | cut -d " " -f 3-7) >> temp.txt

#14. The shell which is used
echo "14. Shell: "$SHELL >> temp.txt

#15. CPU name
echo "15. CPU name: "$(cat /proc/cpuinfo | grep name | cut -f2 -d: | uniq) >> temp.txt




