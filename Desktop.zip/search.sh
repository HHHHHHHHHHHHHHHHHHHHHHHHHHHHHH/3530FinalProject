#!/bin/sh

COUNTER=1

while [ $COUNTER -lt 254 ]
do
	   ping 192.168.1.$COUNTER -c 1 >> result.txt
	      COUNTER=$(( $COUNTER + 1 ))
done
cat result.txt | grep "^64"
rm -rf result.txt
