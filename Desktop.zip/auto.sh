#!/bin/bash

#Make master.txt
./info.sh && cat temp.txt > master.txt

#Make node1.txt
scp info.sh user2@192.168.1.20:~/Desktop
ssh user2@192.168.1.20 "sudo -S ./Desktop/info.sh && cat temp.txt > Desktop/node1.txt"
scp user2@192.168.1.20:~/Desktop/node1.txt ./

#Make node2.txt
scp info.sh user3@192.168.1.30:~/Desktop
ssh user3@192.168.1.30 "sudo -S ./Desktop/info.sh && cat temp.txt > Desktop/node2.txt"
scp user3@192.168.1.30:~/Desktop/node2.txt ./

#Put all of them to together.txt and remove them
cat master.txt > together.txt
echo -e "\n\n" >> together.txt
cat node1.txt >> together.txt
echo -e "\n\n" >> together.txt
cat node2.txt >> together.txt
rm master.txt node1.txt node2.txt temp.txt

#Install Docker in the instance of AWS
sudo ssh -i default.pem ec2-user@18.220.86.148 /bin/bash << EOF
sudo yum install httpd
y
sudo service httpd start
sudo yum install docker
sudo service docker start
sudo docker run -dit --name my-apache-app -p 8080:80 -v "$PWD":/usr/local/apache2/htdocs/ httpd:2.4
sudo service httpd stop
sudo rm -rf /var/www/html/*
EOF

#Put together.txt into index.html
rm -rf index.html
touch index.html
cat <<- EOF >> index.html
<!DOCTYPE HTML>
<html>
<head>
<title>Results</title>
</head>
<body>
<h1>Hosts Information</h1>
<b>
<pre>
EOF
cat together.txt >> index.html
cat <<- EOF >> index.html
</pre>
</b>
</body>
</html>
EOF

#Put the index.html into AWS
sudo ssh -i default.pem ec2-user@18.220.86.148 "sudo chmod -R 777 /var/www"
sudo scp -i default.pem index.html ec2-user@18.220.86.148:/var/www/html/index.html
sudo ssh -i default.pem ec2-user@18.220.86.148 "sudo service httpd start"
